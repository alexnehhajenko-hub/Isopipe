/* ---- IsoPipe PRO (pro4.5) ---- */

/* Кэш/меню */
if('serviceWorker' in navigator){
  navigator.serviceWorker.getRegistrations?.().then(ls=>ls.forEach(r=>r.unregister()));
  caches?.keys?.().then(keys=>keys.forEach(k=>caches.delete(k)));
}
addEventListener('contextmenu',e=>e.preventDefault(),{capture:true});
document.documentElement.style.userSelect='none';
document.documentElement.style.webkitUserSelect='none';

const $=id=>document.getElementById(id);

/* Canvas & UI */
const canvas=$('stage'), ctx=canvas.getContext('2d');
const DPR=Math.max(1, Math.floor(devicePixelRatio||1));
const MIN_SCALE=0.0015, MAX_SCALE=64;

/* HUD */
const lenInput=$('len'), angInput=$('ang'), okBtn=$('ok');
const dirBtns=[$('dir-nw'),$('dir-n'),$('dir-ne'),$('dir-sw'),$('dir-s'),$('dir-se')];
const setPointBtn=$('set-point'), undoBtn=$('undo'), clearBtn=$('clear'), labelsBtn=$('labels');
const toggleBuild=$('toggle-build');

const photoBtn=$('photo-btn'), photoInput=$('photo-input'), settingsBtn=$('settings');
const traceBtn=$('trace'), traceHUD=$('trace-hud'), traceLineBtn=$('trace-line'), traceSave=$('trace-save'), traceExit=$('trace-exit');

const printBtn=$('print'), shareBtn=$('share'), exportBtn=$('export');

const gridModeBtn=$('grid-mode'), gridStick=$('grid-stick'), gridRot=$('grid-rot');
const gridRotL=$('grid-rot-left'), gridRotR=$('grid-rot-right'), gridReset=$('grid-reset');
const isoCalBtn=$('iso-cal');

const dlg=$('photo-dialog'), dlgClose=$('dlg-close');
const photoAlpha=$('photo-alpha'), photoDim=$('photo-dim'),
      photoBright=$('photo-bright'), photoContrast=$('photo-contrast'),
      photoBlur=$('photo-blur'), photoInExport=$('photo-in-export'), photoLock=$('photo-lock');

const cdlg=$('calib-dialog'), calibHint=$('calib-hint'), calibMm=$('calib-mm'),
      calibApply=$('calib-apply'), calibCancel=$('calib-cancel');

const toastEl=$('toast');
const toast=(t,ms=2000)=>{toastEl.textContent=t;toastEl.classList.add('show');setTimeout(()=>toastEl.classList.remove('show'),ms);};

/* State */
let W=0,H=0;
const state={
  origin:{x:0,y:0}, scale:0.6,
  cursor:{x:0,y:0}, activeDir:'ne',
  path:[], showLabels:true,
  mode:'none', // none | point | trace | calib | isocal
  photo:{ img:null, worldPos:{x:-600,y:-400}, worldSize:{w:1200,h:800},
          alpha:.6, dim:false, bright:1, contrast:1, blur:0, locked:false },
  calib:{p1:null,p2:null},
  grid:{ offset:{x:0,y:0}, rot:0 },
  trace:{ start:null, armed:false }, // armed=true после нажатия "Линия"
  iso:{ p1:null,p2:null }           // для ISO-калибровки ориентации
};
let clone={active:false,segs:[],offset:{x:0,y:0},pointerId:null,lastScreen:null};
let gridMode=false;  // настройка сетки
let buildCollapsed=false;

/* Utils */
const DIR_ANGLE={ne:30,nw:150,se:330,sw:210,n:90,s:270};
const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
const toRad=d=>d*Math.PI/180;
const onlyNumber=s=>{if(s==null)return null;const m=String(s).replace(',','.').match(/-?\d+(\.\d+)?/);return m?Number(m[0]):null;};
const formatLen=mm=>!isFinite(mm)?'':(Math.abs(mm)>=1000?(mm/1000).toFixed(1)+' м':Math.round(mm)+' мм');
const worldToScreen=p=>({x:p.x*state.scale*DPR+state.origin.x,y:p.y*state.scale*DPR+state.origin.y});
const screenToWorld=p=>({x:(p.x-state.origin.x)/(state.scale*DPR),y:(p.y-state.origin.y)/(state.scale*DPR)});
function roundedRect(ctx,x,y,w,h,r){const rr=Math.min(r,w/2,h/2);ctx.beginPath();ctx.moveTo(x+rr,y);ctx.arcTo(x+w,y,x+w,y+h,rr);ctx.arcTo(x+w,y+h,x,y+h,rr);ctx.arcTo(x,y+h,x,y,rr);ctx.arcTo(x,y,x+w,y,rr);ctx.closePath();}
function rotVec(x,y,deg){const a=toRad(deg);const c=Math.cos(a), s=Math.sin(a);return {x:x*c - y*s, y:x*s + y*c};}

/* Fit & zoom */
function fit(){ W=canvas.clientWidth*DPR; H=canvas.clientHeight*DPR; canvas.width=W; canvas.height=H; if(state.origin.x===0&&state.origin.y===0){state.origin.x=W/2;state.origin.y=H/2;} draw(); }
addEventListener('resize',fit);

function fitToPhoto(pad=0.92){
  if(!state.photo.img) return;
  const w=state.photo.worldSize.w, h=state.photo.worldSize.h;
  const sx=(W/DPR)/w*pad, sy=(H/DPR)/h*pad;
  state.scale=clamp(Math.min(sx,sy),MIN_SCALE,MAX_SCALE);
  const cx=state.photo.worldPos.x+w/2, cy=state.photo.worldPos.y+h/2;
  const s=state.scale*DPR;
  state.origin.x=W/2 - cx*s;
  state.origin.y=H/2 - cy*s;
  draw();
}

function zoomAt(sx,sy,f){ const w0=screenToWorld({x:sx,y:sy}); state.scale=clamp(state.scale*f,MIN_SCALE,MAX_SCALE); const s1=worldToScreen(w0); state.origin.x+=(sx-s1.x); state.origin.y+=(sy-s1.y); }

/* Photo */
function photoFilter(){const p=state.photo;const b=(p.bright*100)|0,c=(p.contrast*100)|0,blur=p.blur.toFixed(1);return `brightness(${b}%) contrast(${c}%) blur(${blur}px)`;}
function drawPhoto(){const p=state.photo;if(!p.img)return;const A=worldToScreen(p.worldPos), sz={w:p.worldSize.w*state.scale*DPR,h:p.worldSize.h*state.scale*DPR};ctx.save();ctx.globalAlpha=clamp(p.alpha,0,1);ctx.filter=photoFilter();ctx.drawImage(p.img,A.x,A.y,sz.w,sz.h);ctx.filter='none';if(p.dim){ctx.fillStyle='rgba(0,0,0,0.3)';ctx.fillRect(A.x,A.y,sz.w,sz.h);}ctx.restore();}

/* Grid */
function pickStepWorld(){ const desiredPx=56, wpp=1/(state.scale*DPR), t=desiredPx*wpp, p10=Math.pow(10,Math.floor(Math.log10(t||1))); const c=[1,2,5].map(m=>m*p10); return c.reduce((b,x)=>Math.abs(x-t)<Math.abs(b-t)?x:b,c[0]); }
function drawGrid(){
  const stepW=pickStepWorld();
  const dirsRaw=[{ux:0,uy:1},{ux:Math.cos(toRad(30)),uy:Math.sin(toRad(30))},{ux:Math.cos(toRad(-30)),uy:Math.sin(toRad(-30))}]
    .map(d=>rotVec(d.ux,d.uy,state.grid.rot));
  const corners=[screenToWorld({x:0,y:0}),screenToWorld({x:W,y:0}),screenToWorld({x:0,y:H}),screenToWorld({x:W,y:H})]
    .map(c=>({x:c.x - state.grid.offset.x, y:c.y - state.grid.offset.y}));
  ctx.save(); ctx.lineCap='butt';
  dirsRaw.forEach(({ux,uy})=>{
    const nx=-uy, ny=ux, nLen=Math.hypot(nx,ny)||1, nux=nx/nLen, nuy=ny/nLen;
    const uLen=Math.hypot(ux,uy)||1, uux=ux/uLen, uuy=uy/uLen;
    let minD=+Infinity, maxD=-Infinity; for(const c of corners){ const d=c.x*nux+c.y*nuy; if(d<minD)minD=d; if(d>maxD)maxD=d; }
    const k0=Math.floor(minD/stepW)-2, k1=Math.ceil(maxD/stepW)+2;
    const wc=screenToWorld({x:W/2,y:H/2}); wc.x -= state.grid.offset.x; wc.y -= state.grid.offset.y;
    const vw=Math.hypot(corners[1].x-corners[0].x,corners[1].y-corners[0].y), vh=Math.hypot(corners[2].x-corners[0].x,corners[2].y-corners[0].y);
    const span=Math.sqrt(vw*vw+vh*vh)+stepW*4;
    for(let k=k0;k<=k1;k++){
      const c=k*stepW, t=c-(wc.x*nux+wc.y*nuy), p0={x:wc.x+nux*t,y:wc.y+nuy*t};
      const a={x:p0.x-uux*span,y:p0.y-uuy*span}, b={x:p0.x+uux*span,y:p0.y+uuy*span};
      const aw={x:a.x+state.grid.offset.x,y:a.y+state.grid.offset.y};
      const bw={x:b.x+state.grid.offset.x,y:b.y+state.grid.offset.y};
      const A=worldToScreen(aw), B=worldToScreen(bw), isMajor=(k%5===0);
      ctx.globalAlpha=isMajor?0.35:0.20; ctx.strokeStyle=isMajor?'#b7bcc8':'#cfd3dc'; ctx.lineWidth=isMajor?1.5*DPR:1*DPR;
      ctx.beginPath(); ctx.moveTo(A.x,A.y); ctx.lineTo(B.x,B.y); ctx.stroke();
    }
  });
  // оси
  const originW={x:state.grid.offset.x, y:state.grid.offset.y};
  const v0=rotVec(0,1,state.grid.rot), v1=rotVec(Math.cos(toRad(30)),Math.sin(toRad(30)),state.grid.rot), v2=rotVec(Math.cos(toRad(-30)),Math.sin(toRad(-30)),state.grid.rot);
  let A1=worldToScreen({x:originW.x - v0.x*99999, y:originW.y - v0.y*99999});
  let A2=worldToScreen({x:originW.x + v0.x*99999, y:originW.y + v0.y*99999});
  ctx.globalAlpha=.45; ctx.strokeStyle='#8892a6'; ctx.lineWidth=2*DPR; ctx.beginPath(); ctx.moveTo(A1.x,A1.y); ctx.lineTo(A2.x,A2.y); ctx.stroke();
  A1=worldToScreen({x:originW.x - v1.x*99999, y:originW.y - v1.y*99999});
  A2=worldToScreen({x:originW.x + v1.x*99999, y:originW.y + v1.y*99999});
  ctx.beginPath(); ctx.moveTo(A1.x,A1.y); ctx.lineTo(A2.x,A2.y); ctx.stroke();
  A1=worldToScreen({x:originW.x - v2.x*99999, y:originW.y - v2.y*99999});
  A2=worldToScreen({x:originW.x + v2.x*99999, y:originW.y + v2.y*99999});
  ctx.beginPath(); ctx.moveTo(A1.x,A1.y); ctx.lineTo(A2.x,A2.y); ctx.stroke();
  ctx.globalAlpha=1; ctx.restore();
}

/* Pipes & labels */
function drawPipeSegment(seg,alpha=1,isClone=false){
  const a=worldToScreen(seg.from), b=worldToScreen(seg.to);
  ctx.lineCap='round'; ctx.lineJoin='round';
  ctx.lineWidth=8*DPR; ctx.strokeStyle=isClone?'#6640a8':'#5b00bf'; ctx.globalAlpha=alpha; ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(b.x,b.y); ctx.stroke();
  ctx.lineWidth=6*DPR; ctx.strokeStyle=isClone?'#9a66ff':'#8000ff'; ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(b.x,b.y); ctx.stroke();
  const nx=(b.y-a.y), ny=-(b.x-a.x), len=Math.hypot(nx,ny)||1, ox=(nx/len)*(1.5*DPR), oy=(ny/len)*(1.5*DPR);
  ctx.lineWidth=2*DPR; ctx.strokeStyle='#d9c7ff'; ctx.globalAlpha=.8*alpha; ctx.beginPath(); ctx.moveTo(a.x+ox,a.y+oy); ctx.lineTo(b.x+ox,b.y+oy); ctx.stroke();
  ctx.globalAlpha=1;
}
function drawLabels(){
  if(!state.showLabels) return;
  const basePx=14,minPx=10,maxPx=26; ctx.save(); ctx.textBaseline='middle';
  for(const seg of state.path){
    const L=Math.hypot(seg.to.x-seg.from.x, seg.to.y-seg.from.y), fontPx=clamp(basePx/state.scale,minPx,maxPx);
    ctx.font=`600 ${fontPx}px system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,sans-serif`;
    const text=formatLen(L), m=ctx.measureText(text), padX=8*(fontPx/14), padY=4*(fontPx/14), boxW=m.width+padX*2, boxH=fontPx+padY*2;
    const mid={x:(seg.from.x+seg.to.x)/2,y:(seg.from.y+seg.to.y)/2}, ms=worldToScreen(mid), bx=ms.x-boxW/2, by=ms.y-boxH/2;
    roundedRect(ctx,bx,by,boxW,boxH,6); ctx.fillStyle='rgba(255,255,255,0.95)'; ctx.strokeStyle='#8000ff'; ctx.lineWidth=1*DPR; ctx.fill(); ctx.stroke();
    ctx.fillStyle='#8000ff'; ctx.fillText(text, ms.x-m.width/2, ms.y);
  }
  ctx.restore();
}
function drawCursor(){ const p=worldToScreen(state.cursor); ctx.save(); ctx.lineWidth=2*DPR; const pro = state.mode==='trace'; ctx.fillStyle= pro?'#00a86b':'#8000ff'; ctx.strokeStyle=pro?'#58d3a7':'#a566ff'; ctx.beginPath(); ctx.arc(p.x,p.y,7*DPR,0,Math.PI*2); ctx.fill(); ctx.stroke(); ctx.restore(); }
function drawTraceStartMarker(){ if(!state.trace.start) return; const p=worldToScreen(state.trace.start); ctx.save(); ctx.fillStyle='#00a86b'; ctx.strokeStyle='#58d3a7'; ctx.lineWidth=2*DPR; ctx.beginPath(); ctx.arc(p.x,p.y,8*DPR,0,Math.PI*2); ctx.fill(); ctx.stroke(); ctx.restore(); }

function draw(){ ctx.clearRect(0,0,W,H); drawPhoto(); drawGrid(); for(const s of state.path) drawPipeSegment(s); drawLabels(); drawCursor(); drawTraceStartMarker(); }

/* Build */
function buildAbsolute(lenStr,absDeg){ const L=onlyNumber(lenStr); if(L==null||!isFinite(L)||L<=0) return; const from={...state.cursor}, rad=toRad(absDeg); const to={x:from.x+Math.cos(rad)*L, y:from.y-Math.sin(rad)*L}; state.path.push({from,to}); state.cursor={...to}; draw(); }
function buildRelative(lenStr,relDeg){ const base=DIR_ANGLE[state.activeDir]??30; buildAbsolute(lenStr,(base+relDeg)%360); }
dirBtns.forEach(btn=>btn.addEventListener('click',()=>{
  dirBtns.forEach(b=>b.classList.remove('active')); btn.classList.add('active'); state.activeDir=btn.dataset.dir;
  const angTxt=(angInput.value||'').trim();
  if(angTxt!==''){ const A=onlyNumber(angTxt); if(A!=null) buildRelative(lenInput.value,clamp(A,-360,360)); }
  else { buildAbsolute(lenInput.value, DIR_ANGLE[state.activeDir]??30); }
}));
$('dir-ne').classList.add('active');
okBtn.addEventListener('click',()=>{
  const angTxt=(angInput.value||'').trim();
  if(angTxt!==''){ const A=onlyNumber(angTxt); if(A!=null) buildRelative(lenInput.value,clamp(A,-360,360)); }
  else { buildAbsolute(lenInput.value, DIR_ANGLE[state.activeDir]??30); }
});
labelsBtn.addEventListener('click',()=>{ state.showLabels=!state.showLabels; labelsBtn.classList.toggle('active',state.showLabels); draw(); });
toggleBuild.addEventListener('click',()=>{ const p=$('panel-build'); buildCollapsed=!buildCollapsed; p.style.display=buildCollapsed?'none':'block'; });

/* Печать/шеринг/экспорт */
function doPrint(){ window.print(); }
async function doShare(){
  try{
    const blob=await new Promise(r=>canvas.toBlob(r,'image/png',0.95));
    const file=new File([blob],'IsoPipe.png',{type:'image/png'});
    if(navigator.canShare && navigator.canShare({files:[file]})) await navigator.share({title:'IsoPipe', files:[file]});
    else { const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='IsoPipe.png'; a.click(); URL.revokeObjectURL(url); }
  }catch{ const url=canvas.toDataURL('image/png'); const a=document.createElement('a'); a.href=url; a.download='IsoPipe.png'; a.click(); }
}
printBtn.addEventListener('click',doPrint);
shareBtn.addEventListener('click',doShare);
exportBtn.addEventListener('click',()=>{
  const wantPhoto=photoInExport?.checked;
  const off=document.createElement('canvas'); off.width=W; off.height=H; const c=off.getContext('2d');
  c.fillStyle=getComputedStyle(document.documentElement).getPropertyValue('--canvas').trim()||'#fff';
  c.fillRect(0,0,W,H);
  if(wantPhoto && state.photo.img){
    const p=state.photo, A=worldToScreen(p.worldPos), sz={w:p.worldSize.w*state.scale*DPR, h:p.worldSize.h*state.scale*DPR};
    c.globalAlpha=clamp(p.alpha,0,1); c.filter=photoFilter(); c.drawImage(p.img,A.x,A.y,sz.w,sz.h); c.filter='none';
    if(p.dim){ c.fillStyle='rgba(0,0,0,0.3)'; c.fillRect(A.x,A.y,sz.w,sz.h); }
    c.globalAlpha=1;
  }
  c.drawImage(canvas,0,0);
  const url=off.toDataURL('image/png'); const a=document.createElement('a'); a.href=url; a.download='IsoPipe.png'; a.click();
});

/* Настройки фото */
settingsBtn?.addEventListener('click',()=>{ if(!state.photo.img){ toast('Сначала добавьте фото'); return; } dlg.showModal(); });
dlgClose?.addEventListener('click',()=>dlg.close());
photoBtn.addEventListener('click',()=>photoInput.click());
photoInput.addEventListener('change',()=>{
  const f=photoInput.files?.[0]; if(!f){ toast('Фото не выбрано'); return; }
  const url=URL.createObjectURL(f), img=new Image();
  img.onload=()=>{ URL.revokeObjectURL(url); state.photo.img=img;
    const k=1200, aspect=img.width/img.height||1;
    state.photo.worldSize={w:k, h:k/aspect}; state.photo.worldPos={x:-k/2, y:-k/(2*aspect)};
    fitToPhoto(0.92); toast('Фото добавлено'); draw();
  };
  img.src=url;
});
photoAlpha?.addEventListener('input',()=>{ state.photo.alpha=Number(photoAlpha.value)/100; draw(); });
photoDim  ?.addEventListener('change',()=>{ state.photo.dim=photoDim.checked; draw(); });
photoBright?.addEventListener('input',()=>{ state.photo.bright=Number(photoBright.value)/100; draw(); });
photoContrast?.addEventListener('input',()=>{ state.photo.contrast=Number(photoContrast.value)/100; draw(); });
photoBlur?.addEventListener('input',()=>{ state.photo.blur=Number(photoBlur.value); draw(); });
photoLock?.addEventListener('change',()=>{ state.photo.locked=photoLock.checked; toast(state.photo.locked?'Фото заблокировано':'Фото разблокировано'); });

/* Режимы сетки */
gridModeBtn.addEventListener('click',()=>{
  gridMode=!gridMode; gridStick.style.display=gridMode?'flex':'none'; gridRot.style.display=gridMode?'flex':'none';
  toast(gridMode?'Настройка сетки: тяните по холсту (сдвиг), щипок — вращение':'Настройка сетки: выкл');
});
gridStick.style.display='none'; gridRot.style.display='none';
gridRotL.addEventListener('click',()=>{ state.grid.rot=(state.grid.rot-1+360)%360; draw(); });
gridRotR.addEventListener('click',()=>{ state.grid.rot=(state.grid.rot+1)%360; draw(); });
gridReset.addEventListener('click',()=>{ state.grid.rot=0; state.grid.offset={x:0,y:0}; draw(); });

/* ISO-калибровка ориентации (под фото/рисунок 3D) */
isoCalBtn.addEventListener('click',()=>{
  state.mode = state.mode==='isocal' ? 'none' : 'isocal';
  state.iso.p1=null; state.iso.p2=null;
  toast(state.mode==='isocal'?'ISO-калибровка: укажите линию оси (2 тапа)':'ISO-калибровка: выкл');
});

/* Джойстик сетки — визуальный */
let stickDrag=false, lastStick=null;
gridStick.addEventListener('pointerdown',e=>{ gridStick.setPointerCapture?.(e.pointerId); stickDrag=true; lastStick={x:e.clientX*DPR,y:e.clientY*DPR}; e.preventDefault(); });
gridStick.addEventListener('pointermove',e=>{
  if(!stickDrag) return;
  const cur={x:e.clientX*DPR,y:e.clientY*DPR}, d={dx:cur.x-(lastStick?.x??cur.x), dy:cur.y-(lastStick?.y??cur.y)};
  const dot=gridStick.querySelector('.dot'); dot.style.transform=`translate(${clamp(d.dx,-20*DPR,20*DPR)/DPR}px, ${clamp(d.dy,-20*DPR,20*DPR)/DPR}px)`;
  state.grid.offset.x += d.dx/(state.scale*DPR);
  state.grid.offset.y += d.dy/(state.scale*DPR);
  lastStick=cur; draw();
});
gridStick.addEventListener('pointerup',()=>{ stickDrag=false; lastStick=null; gridStick.querySelector('.dot').style.transform='translate(0,0)'; });
gridStick.addEventListener('pointercancel',()=>{ stickDrag=false; lastStick=null; gridStick.querySelector('.dot').style.transform='translate(0,0)'; });

/* Trace mode: арматура линии */
function enterTraceFocus(){
  state.mode='trace'; state.trace.start=null; state.trace.armed=false;
  $('panel-build').style.display='none';
  document.querySelector('.fab-col.left').style.display='none';
  document.querySelector('.fab-col.right').style.display='none';
  gridStick.style.display='none'; gridRot.style.display='none'; gridMode=false;
  traceHUD.classList.remove('hidden');
  toast('Нажмите «Линия», затем: 1-я точка → 2-я точка');
}
function exitTraceFocus(){
  state.mode='none'; state.trace.start=null; state.trace.armed=false;
  $('panel-build').style.display=buildCollapsed?'none':'block';
  document.querySelector('.fab-col.left').style.display='';
  document.querySelector('.fab-col.right').style.display='';
  traceHUD.classList.add('hidden');
  toast('Трассировка завершена');
}
traceBtn.addEventListener('click',()=>{ if(state.mode==='trace') exitTraceFocus(); else enterTraceFocus(); });
traceExit?.addEventListener('click', exitTraceFocus);
traceSave.addEventListener('click',()=>exportBtn.click());
traceLineBtn.addEventListener('click',()=>{
  state.trace.armed=true; state.trace.start=null;
  toast('Линия: тапните 1-ю точку, затем 2-ю');
});

/* Gestures */
let pointers=new Map(), lastOnePos=null, lastTapTime=0, tapStart=null;
const TAP_THR=8*DPR, TAP_GAP=300, LONG_MS=500;
let longTimer=null, longStart=null;
function clearLong(){ if(longTimer){clearTimeout(longTimer);} longTimer=null; longStart=null; }

function tryStartCloneAt(screenPt,pid){
  if(state.mode!=='none'||!state.path.length) return;
  const THR=18*DPR; const tapWorld=screenToWorld(screenPt); let near=false;
  for(const seg of state.path){
    const ax=seg.from.x, ay=seg.from.y, bx=seg.to.x, by=seg.to.y;
    const t=((tapWorld.x-ax)*(bx-ax)+(tapWorld.y-ay)*(by-ay))/((bx-ax)*(bx-ax)+(by-ay)*(by-ay)||1);
    const clx=ax+clamp(t,0,1)*(bx-ax), cly=ay+clamp(t,0,1)*(by-ay);
    const p=worldToScreen({x:clx,y:cly});
    if(Math.hypot(p.x-screenPt.x,p.y-screenPt.y)<=THR){near=true; break;}
  }
  if(!near) return;
  clone.active=true; clone.segs=state.path.map(s=>({from:{...s.from},to:{...s.to}}));
  clone.offset={x:10,y:10}; clone.pointerId=pid; clone.lastScreen=screenPt; draw();
}

canvas.addEventListener('pointerdown',(e)=>{
  canvas.setPointerCapture?.(e.pointerId);
  const p={x:e.clientX*DPR,y:e.clientY*DPR,t:performance.now()}; pointers.set(e.pointerId,p);
  if(pointers.size===1){
    lastOnePos={x:p.x,y:p.y}; tapStart=p; longStart=p;
    if(state.mode==='none' && state.path.length){ longTimer=setTimeout(()=>tryStartCloneAt(longStart,e.pointerId),LONG_MS); }
  } else { tapStart=null; clearLong(); }
});

canvas.addEventListener('pointermove',(e)=>{
  if(!pointers.has(e.pointerId)) return;
  const cur={x:e.clientX*DPR,y:e.clientY*DPR,t:performance.now()}, prev=pointers.get(e.pointerId);
  pointers.set(e.pointerId,cur);
  if(tapStart && Math.hypot(cur.x-tapStart.x,cur.y-tapStart.y)>TAP_THR) tapStart=null;
  if(longStart && Math.hypot(cur.x-longStart.x,cur.y-longStart.y)>TAP_THR) clearLong();

  // Режим настройки сетки
  if(gridMode){
    if(pointers.size===1 && lastOnePos){
      const dW={x:(cur.x-lastOnePos.x)/(state.scale*DPR), y:(cur.y-lastOnePos.y)/(state.scale*DPR)};
      state.grid.offset.x+=dW.x; state.grid.offset.y+=dW.y;
      lastOnePos={x:cur.x,y:cur.y}; draw(); return;
    } else if(pointers.size===2){
      const ids=[...pointers.keys()], p1=pointers.get(ids[0]), p2=pointers.get(ids[1]);
      const prv1=(ids[0]===e.pointerId)?prev:p1, prv2=(ids[1]===e.pointerId)?prev:p2;
      const angPrev=Math.atan2(prv2.y-prv1.y, prv2.x-prv1.x);
      const angCur =Math.atan2(p2.y-p1.y,   p2.x-p1.x);
      const dDeg=(angCur-angPrev)*180/Math.PI;
      state.grid.rot=(state.grid.rot + dDeg)%360; draw(); return;
    }
  }

  // Пан/зум: в «trace» разрешаем ТОЛЬКО зум двумя пальцами (для увеличения фото), пан — запрещён
  const allowPan = state.mode!=='trace';
  const allowZoom = (state.mode!=='trace') || (pointers.size===2);

  if(clone.active && clone.pointerId===e.pointerId){
    const d={dx:cur.x-(clone.lastScreen?.x??cur.x), dy:cur.y-(clone.lastScreen?.y??cur.y)};
    const dW={x:d.dx/(state.scale*DPR), y:d.dy/(state.scale*DPR)};
    clone.offset.x+=dW.x; clone.offset.y+=dW.y; clone.lastScreen={x:cur.x,y:cur.y}; draw(); return;
  }
  if(pointers.size===1 && lastOnePos && allowPan){
    state.origin.x += (cur.x-lastOnePos.x);
    state.origin.y += (cur.y-lastOnePos.y);
    lastOnePos={x:cur.x,y:cur.y}; draw();
  } else if(pointers.size===2 && allowZoom){
    const ids=[...pointers.keys()], p1=pointers.get(ids[0]), p2=pointers.get(ids[1]);
    const prv1=(ids[0]===e.pointerId)?prev:p1, prv2=(ids[1]===e.pointerId)?prev:p2;
    const cPrev={x:(prv1.x+prv2.x)/2, y:(prv1.y+prv2.y)/2}, cCur={x:(p1.x+p2.x)/2, y:(p1.y+p2.y)/2};
    const dPrev=Math.hypot(prv1.x-prv2.x,prv1.y-prv2.y), dCur=Math.hypot(p1.x-p2.x,p1.y-p2.y);
    if(dPrev&&dCur){ zoomAt(cPrev.x,cPrev.y,dCur/dPrev); if(allowPan){ state.origin.x+=(cCur.x-cPrev.x); state.origin.y+=(cCur.y-cPrev.y); } draw(); }
    lastOnePos=null; tapStart=null; clearLong();
  }
});

canvas.addEventListener('pointerup', onPointerEnd);
canvas.addEventListener('pointercancel', onPointerEnd);

function onPointerEnd(e){
  const up=pointers.get(e.pointerId); pointers.delete(e.pointerId);

  // Завершение копирования
  if(clone.active && clone.pointerId===e.pointerId){
    for(const s of clone.segs){
      state.path.push({from:{x:s.from.x+clone.offset.x,y:s.from.y+clone.offset.y}, to:{x:s.to.x+clone.offset.x,y:s.to.y+clone.offset.y}});
    }
    clone={active:false,segs:[],offset:{x:0,y:0},pointerId:null,lastScreen:null}; draw();
  }

  // ISO-калибровка ориентации (2 точки → повернуть сетку к ближайшему изо-углу)
  if(state.mode==='isocal' && up){
    const w=screenToWorld(up);
    if(!state.iso.p1){ state.iso.p1=w; toast('Укажите вторую точку оси'); }
    else{
      state.iso.p2=w;
      const dx=state.iso.p2.x-state.iso.p1.x, dy=state.iso.p2.y-state.iso.p1.y;
      let ang=(Math.atan2(-dy,dx)*180/Math.PI+360)%360;
      const iso=[30,90,150,210,270,330];
      let best=iso[0], diff=1e9; for(const a of iso){ const d=Math.min(Math.abs(ang-a), 360-Math.abs(ang-a)); if(d<diff){diff=d;best=a;} }
      const delta=(best-ang+360)%360;
      state.grid.rot=(state.grid.rot+delta)%360;
      state.mode='none'; state.iso.p1=null; state.iso.p2=null;
      toast('Ориентация сетки выровнена под 3D'); draw();
    }
    return;
  }

  // Трассировка по точкам: работает только после «Линия»
  if(state.mode==='trace' && state.trace.armed && up){
    const w=screenToWorld(up);
    if(!state.trace.start){ state.trace.start=w; draw(); }
    else{
      const from={...state.trace.start}, to={...w};
      state.path.push({from,to}); state.cursor={...to};
      state.trace.start=null; state.trace.armed=false; // схема завершена
      toast('Линия построена'); draw();
    }
    return;
  }

  // Double tap — свернуть/развернуть панель
  if(!pointers.size && up){
    const now=performance.now(), dt=now-lastTapTime;
    if(dt<TAP_GAP){ const panel=$('panel-build'); buildCollapsed=!buildCollapsed; panel.style.display=buildCollapsed?'none':'block'; lastTapTime=0; return; }
    lastTapTime=now;
  }

  if(!pointers.size){ lastOnePos=null; tapStart=null; clearLong(); }
}

/* Колесо мыши: в trace разрешаем зум (пан нельзя) */
canvas.addEventListener('wheel',(e)=>{
  e.preventDefault();
  const r=canvas.getBoundingClientRect(); const sx=(e.clientX-r.left)*DPR, sy=(e.clientY-r.top)*DPR;
  zoomAt(sx,sy,e.deltaY<0?1.1:0.9); draw();
},{passive:false});

/* Undo/Clear/Point */
undoBtn.addEventListener('click',()=>{ const last=state.path.pop(); if(last) state.cursor={...last.from}; draw(); });
clearBtn.addEventListener('click',()=>{ state.path=[]; state.cursor={x:0,y:0}; state.trace.start=null; state.trace.armed=false; draw(); });
setPointBtn.addEventListener('click',()=>{ state.mode = state.mode==='point' ? 'none' : 'point'; setPointBtn.classList.toggle('active', state.mode==='point'); toast(state.mode==='point'?'Режим точки: вкл':'Режим точки: выкл'); });

/* Старт */
function boot(){ fit(); }
boot();
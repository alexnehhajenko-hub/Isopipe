// ballvalve.js — ISO шаровый кран: круг с диагональю + ручка
(function (global){
  function draw(ctx, Ax,Ay, Bx,By, opts={}) {
    const color   = opts.color   || '#7b2cff';
    const outline = opts.outline || '#5b00bf';
    const linePx  = opts.linePx  || 7;
    const handleMode = opts.handleMode || 'auto';

    IsoCore.drawPipeChunk(ctx, Ax,Ay, Bx,By, linePx, color, outline);

    const cx=(Ax+Bx)/2, cy=(Ay+By)/2;
    const vx=Bx-Ax, vy=By-Ay;
    const ang=Math.atan2(vy, vx);

    const R = Math.min(IsoCore.mm(3.2), (IsoCore.mm(7)*0.5)); // радиус круга

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(ang);

    // круг
    ctx.strokeStyle = '#111'; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(0,0, R, 0, Math.PI*2); ctx.stroke();

    // диагональ
    ctx.beginPath(); ctx.moveTo(-R*0.9, -R*0.9); ctx.lineTo(R*0.9, R*0.9); ctx.stroke();

    ctx.restore();

    IsoCore.drawHandle(ctx, cx, cy - (IsoCore.mm(7)*0.55), ang, handleMode);
  }

  global.IsoBallValve = { draw };
})(window);
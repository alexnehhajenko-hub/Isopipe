// iso-elements-core.js — общие утилиты для элементов (10 мм вставка)
(function (global) {
  const CSS_PX_PER_MM = 96 / 25.4; // 1 inch = 25.4mm = 96 CSS px
  const DPR = Math.max(1, Math.min(3, window.devicePixelRatio || 1));
  const PX_PER_MM = CSS_PX_PER_MM * DPR;

  function mm(v) { return v * PX_PER_MM; }        // мм -> device px
  function len10mm() { return mm(10); }           // длина вставки
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function drawPipeChunk(ctx, Ax, Ay, Bx, By, linePx, color='#7b2cff', outline='#5b00bf') {
    ctx.save();
    // линия под символом — «кусок трубы»
    ctx.lineCap='round'; ctx.lineJoin='round';
    ctx.strokeStyle = outline; ctx.lineWidth = linePx + 2;
    ctx.beginPath(); ctx.moveTo(Ax,Ay); ctx.lineTo(Bx,By); ctx.stroke();
    ctx.strokeStyle = color;   ctx.lineWidth = linePx;
    ctx.beginPath(); ctx.moveTo(Ax,Ay); ctx.lineTo(Bx,By); ctx.stroke();
    ctx.restore();
  }

  // ориентация ручки:
  //  - 'auto' : если труба горизонтальная — вверх; если вертикальная — «фронтальная» метка (короткая толстая черта)
  //  - 'up'   : всегда вверх
  //  - 'dot'  : точка по центру (вариант фронтальной метки)
  function drawHandle(ctx, cx, cy, angRad, mode='auto') {
    const upLen = mm(3.5);
    const upW   = Math.max(1.4, mm(0.6));
    const frontLen = mm(3.8);
    const frontW   = Math.max(1.8, mm(0.9));

    // Насколько сегмент «похож» на горизонтальный: |cos(ang)|
    const horizness = Math.abs(Math.cos(angRad));

    if (mode === 'up' || (mode === 'auto' && horizness >= 0.707)) {
      // ручка вверх (в экранных координатах по -Y)
      ctx.save();
      ctx.strokeStyle = '#7b2cff';
      ctx.lineWidth = upW + 0.8;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx, cy - upLen); ctx.stroke();
      ctx.strokeStyle = '#5b00bf';
      ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(cx, cy - upLen); ctx.lineTo(cx, cy - upLen); ctx.stroke();
      ctx.restore();
      return;
    }

    if (mode === 'dot') {
      ctx.save();
      ctx.fillStyle = '#7b2cff';
      ctx.beginPath(); ctx.arc(cx, cy, Math.max(1.5, mm(0.7)), 0, Math.PI*2); ctx.fill();
      ctx.restore();
      return;
    }

    // «фронтальная» короткая метка для вертикальной трубы — небольшая жирная черточка
    ctx.save();
    ctx.strokeStyle = '#7b2cff';
    ctx.lineWidth = frontW;
    ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(cx - frontLen/2, cy); ctx.lineTo(cx + frontLen/2, cy); ctx.stroke();
    ctx.restore();
  }

  // вспомогательный прямоугольник со скруглениями
  function rr(ctx, x, y, w, h, r) {
    const rad = Math.max(0, Math.min(r, Math.min(w, h)/2));
    ctx.beginPath();
    ctx.moveTo(x+rad, y);
    ctx.arcTo(x+w,y,   x+w,y+h, rad);
    ctx.arcTo(x+w,y+h, x,  y+h, rad);
    ctx.arcTo(x,  y+h, x,  y,   rad);
    ctx.arcTo(x,  y,   x+w,y,   rad);
    ctx.closePath();
  }

  global.IsoCore = { mm, len10mm, drawPipeChunk, drawHandle, rr, PX_PER_MM, DPR };
})(window);
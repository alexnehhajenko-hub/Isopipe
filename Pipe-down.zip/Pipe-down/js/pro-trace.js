const cv = document.getElementById('cv');
const ctx = cv.getContext('2d');

function fitCanvas() {
  cv.width = window.innerWidth;
  cv.height = window.innerHeight;
  draw();
}

function draw() {
  ctx.clearRect(0, 0, cv.width, cv.height);
  ctx.fillStyle = "#8000ff";
  ctx.beginPath();
  ctx.arc(cv.width/2, cv.height/2, 40, 0, Math.PI*2);
  ctx.fill();
}

window.addEventListener('resize', fitCanvas);
fitCanvas();

// Кнопка Фото (для теста работает alert)
document.getElementById('btnPhoto')?.addEventListener('click', () => {
  alert("Фото нажато!");
});
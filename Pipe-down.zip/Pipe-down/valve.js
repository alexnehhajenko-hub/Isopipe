// valve.js — ISO вентиль: ромб (два треугольника) + ручка
(function (global){
  function draw(ctx, Ax,Ay, Bx,By, opts={}) {
    const color   = opts.color   || '#7b2cff';
    const outline = opts.outline || '#5b00bf';
    const linePx  = opts.linePx  || 7;             // толщина трубы (px)
    const handleMode = opts.handleMode || 'auto';  // 'auto' | 'up' | 'dot'

    // кусок трубы
    IsoCore.drawPipeChunk(ctx, Ax,Ay, Bx,By, linePx, color, outline);

    // геометрия символа
    const cx=(Ax+Bx)/2, cy=(Ay+By)/2;
    const vx=Bx-Ax, vy=By-Ay;
    const ang=Math.atan2(vy, vx);
    const symH = IsoCore.mm(7)*0.9;  // высота ромба
    const symW = IsoCore.mm(10)*0.9; // ширина (вдоль трубы)

    // ромб
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(ang);
    ctx.strokeStyle = '#111';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(0, -symH/2);    // верх
    ctx.lineTo(-symW/2, 0);    // лев
    ctx.lineTo(0,  symH/2);    // низ
    ctx.lineTo( symW/2, 0);    // прав
    ctx.closePath();
    ctx.stroke();
    ctx.restore();

    // ручка-черточка
    IsoCore.drawHandle(ctx, cx, cy - (IsoCore.mm(7)*0.45), ang, handleMode);
  }

  global.IsoValve = { draw };
})(window);